import React, { Component } from 'react';
import './App.css';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import Engine from './component/Engine'
import MainPage from './container/MainPage'
import CarPaint from './component/CarPaint';
import RimColor from './component/RimColor'
import RimSize from './component/RimSize'
import CarSeats from './component/CarSeats';
import UpholsteryColor from './component/UpholsteryColor';
import Equipment from './component/Equipment';
import orderSummary from './component/orderSummary';

class App extends Component {
 
  render() {
 
    return (<div className="App">
      
      <BrowserRouter>
        
  <Switch>
    <Route path="/" exact  component={MainPage} />
    <Route path="/orderSummary"  component={orderSummary} />
    <Route path="/equipment/"  component={Equipment} />
    <Route path="/upholsterycolor/"  component={UpholsteryColor} />
    <Route path="/carseats/"  component={CarSeats} />
    <Route path="/rimesize/"  component={RimSize} />
    <Route path="/rimcolor/"  component={RimColor} />
    <Route path="/carpaint/"  component={CarPaint} />

    <Route path="/engine/"   component={Engine} />
  </Switch>
</BrowserRouter> 
    
    </div>
    
    
    );
  }
}

export default App;

import * as actionTypes from '../reducers/action';

const initialState ={
    counter: 0,
    result: [],
    
}

const reducer = (state=initialState, action) => {
    switch(action.type){
        case actionTypes.ADD:
      
            return{
                ...state,
                counter: state.counter + action.value,
                result: state.result.concat(action.result)
            }
       
default:
    return state;
    };
   

}

export default reducer;


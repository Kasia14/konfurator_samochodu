import React, { Component } from 'react';


import Navbar from '../component/Navbar'
import './mainpage.scss';
import Question from '../component/Question'
import Button from '../component/Button'
import { Link} from 'react-router-dom';


class MainPage extends Component {


   render(){
 
   
        return (
            <div className="mainpage">
                <Navbar/>
                <Question name="Witam Cię w świecie Audi!"/>
               <Link style={{textDecoration: 'none'}} to="/engine/">
                <Button 
              
                btn="Kontynuuj" />
              </Link>
              
                
            </div>
          
        )
    }
}


export default MainPage;
import React from 'react';
import './button.scss';

const button = (props) => {
    return <div>
        <button onClick={props.clicked} className="button  btn btn-light btn-lg ">{props.btn}</button>
    </div>
}

export default button;
import React, { Component } from 'react';

import { connect } from 'react-redux';
import Navbar from '../component/Navbar'
import './page2.scss'
import './cards.scss';
import './modal.scss';
import Auxility from '../hoc/Auxility'

class Page8 extends Component {
    state = {
        totalPrice:0,
        itemList: []
    }

    backHandler = () => {
        this.props.history.goBack();
    }
    render() {
     
        return (
            <div className="mainpage">
          <Navbar />
                <Auxility>
           
               <h3 className ="text">Podsumowanie:</h3>
                <p className="text1">Twoje zamówienie to: </p>
                <ul className="ul">
                    {this.props.storedResults.map(strResult =>(<li key={new Date()}>{strResult}</li>))}
                </ul>
                <h3 className="text-white">Razem do zapłaty: {this.props.ctr} PLN</h3>
            </Auxility>
            


            </div>
        )
    }
}
const mapStateToProps = state => {
    console.log(state);
    return{
        ctr: state.ctr.counter, //global state from index.js
        storedResults: state.ctr.result
    }
}

export default connect(mapStateToProps) (Page8);
import React, { Component } from 'react';
import { Link} from 'react-router-dom';

import Navbar from './Navbar'
import './page2.scss'
import Question from './Question'
import Button from './Button'
import Card from './Card'
import './cards.scss';

class RimColor extends Component {
state={
    rimColor:{
        id:1,
        title: "zdjęcie1",
        describe:"To jest lakier obręczy nr1",
        price:3500
    },
    rimColor1:{
        id:2,
        title: "zdjęcie 2",
        describe: "To jest lakier obręczy nr2",
        price: 4000
    },
    rimColor2:{
        id:3,
        title: "zdjęcie 3",
        describe: "To jest lakier obręczy nr3",
        price: 5500
    },
    purchasable: true
}
purchasableHandler = () => {
    this.setState({purchasable: false})
}  

backHandler = () => {
    this.props.history.goBack();
}
    render(){
        return (
            <div className="mainpage">
                
                <Navbar/>
                <Question name="Wybierz lakier obręczy"/>
              <div className="cards">
          <Card title={this.state.rimColor.title} disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.rimColor.describe} price={this.state.rimColor.price} />
          <Card title={this.state.rimColor1.title}  disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.rimColor1.describe} price={this.state.rimColor1.price} />
          <Card title= {this.state.rimColor2.title} disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.rimColor2.describe} price={this.state.rimColor2.price} />
         
          </div>
          <div className="button1">
        
          <Button clicked={this.backHandler}btn="Wstecz" />
      
          <Link style={{textDecoration: 'none'}} to="/rimesize/">
          <Button btn="Kontynuuj" />
          </Link>
          </div>
       
           
          
            </div>
        )
    }
}


export default RimColor;
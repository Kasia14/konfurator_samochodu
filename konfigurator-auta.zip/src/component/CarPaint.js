import React, { Component } from 'react';
import { Link} from 'react-router-dom';


import Navbar from './Navbar'
import './page2.scss'
import Question from './Question'
import Button from './Button'
import Card from './Card'
import './cards.scss';

class CarPaint extends Component {
state={
    carPaint:{
        id:1,
        title: "zdjęcie1",
        describe:"To jest lakier nr1",
        price:3500
    },
    carPaint1:{
        id:2,
        title: "zdjęcie 2",
        describe: "To jest lakier nr2",
        price: 4000
    },
    carPaint2:{
        id:3,
        title: "zdjęcie 3",
        describe: "To jest lakier nr3",
        price: 5500
    },
    purchasable: true
}

purchasableHandler = () => {
    this.setState({purchasable: false})
}  
backHandler = () => {
    this.props.history.goBack();
}
    render(){
        return (
            <div className="mainpage">
                
                <Navbar/>
                <Question name="Wybierz lakier"/>
              <div className="cards">
          <Card title={this.state.carPaint.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.carPaint.describe} price={this.state.carPaint.price} />
          <Card title={this.state.carPaint1.title} disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.carPaint1.describe} price={this.state.carPaint1.price} />
          <Card title= {this.state.carPaint2.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.carPaint2.describe} price={this.state.carPaint2.price} />
         
          </div>
          <div className="button1">
         
          <Button clicked={this.backHandler}btn="Wstecz" />
        
          <Link style={{textDecoration: 'none'}} to="/rimcolor/">
          <Button btn="Kontynuuj" />
          </Link>
          </div>
       
           
          
            </div>
        )
    }
}


export default  CarPaint;
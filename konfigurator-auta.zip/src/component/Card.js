import React  from 'react';
import { connect } from 'react-redux';
import * as actionTypes from '../reducers/action'


function click(props)
{
  props.onAddCounter(props.price, props.describe);
if(props.selected){
  props.selected()
}
    
  
}

const card =(props) => {


    return (
        
         <div className="col-md-4">
          <div class="card mb-4 shadow-sm">
           <svg className="bd-placeholder-img card-img-top" width="100%" height="150" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false"><rect width="100%" height="100%" fill="#55595c"></rect><text className="text-center"x="50%" y="50%" fill="#eceeef" dy=".3em">{props.title}</text></svg> 

            <div className="card-body" >
              <p className="card-text"><span className="font-weight-bold">Opis:</span>{props.describe}</p>
              <p className="card-text"><span className="font-weight-bold">Cena:</span>{props.price} PLN</p>
              <div class="d-flex justify-content-between align-items-center">
                <div className="btn-group">
                  <button type="button" disabled={props.disabled} onClick={() => click(props)} className="btn btn-sm btn-outline-secondary">Dodaj</button>
                  
                </div>
               
              </div>
            </div>
          </div>
        
        </div>
      
     
      
    )
}

const mapStateToProps = state => {
  return{
      ctr: state.ctr.counter, //global state from index.js
      storedResults: state.res.results
  }
}

const mapDispatchToProps = dispatch => {
  return{
onAddCounter: (price, describe) => dispatch({type:actionTypes.ADD, value: price, result:describe}),


  }
}

 export default connect(mapStateToProps,mapDispatchToProps) (card);
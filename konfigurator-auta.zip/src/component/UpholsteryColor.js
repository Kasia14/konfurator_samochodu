import React, { Component } from 'react';
import { Link} from 'react-router-dom';

import Navbar from './Navbar'
import './page2.scss'
import Question from './Question'
import Button from './Button'
import Card from './Card'
import './cards.scss';


class UpholsteryColor extends Component {
state={
    upholsteryColor:{
        id:1,
        title: "zdjęcie1",
        describe:"Kolor nr1",
        price:1500
    },
    upholsteryColor1:{
        id:2,
        title: "zdjęcie 2",
        describe: "Kolor nr2",
        price: 1000
    },
    upholsteryColor2:{
        id:3,
        title: "zdjęcie 3",
        describe: "Kolor nr3",
        price: 2500
    },
    purchasable: true
}
purchasableHandler = () => {
    this.setState({purchasable: false})
} 
backHandler = () => {
    this.props.history.goBack();
}
    render(){
        return (
            <div className="mainpage">
                
                <Navbar/>
                <Question name="Kolor tapicerki: "/>
              <div className="cards">
          <Card title={this.state.upholsteryColor.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.upholsteryColor.describe} price={this.state.upholsteryColor.price} />
          <Card title={this.state.upholsteryColor1.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.upholsteryColor1.describe} price={this.state.upholsteryColor1.price} />
          <Card title= {this.state.upholsteryColor2.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.upholsteryColor2.describe} price={this.state.upholsteryColor2.price} />
         
          </div>
          <div className="button1">
        
          <Button clicked={this.backHandler}btn="Wstecz" />
      
          <Link style={{textDecoration: 'none'}} to="/equipment/">
          <Button btn="Kontynuuj" />
          </Link>
          </div>
       
           
          
            </div>
        )
    }
}


export default UpholsteryColor;
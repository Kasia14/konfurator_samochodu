import React from 'react';

import logo from '../images/logoAudi.png'

const Navbar = () => (
    <div className="navbar navbar-light bg-light">
   <h3 className="h2">Audi</h3>
        <div className="navbar-brand" >
            <img src={logo} width="70" height="30" alt="logo" />
        </div>
    </div>

);

export default Navbar;
import React, { Component } from 'react';
import { Link} from 'react-router-dom';


import Navbar from './Navbar'
import './page2.scss'
import Question from './Question'
import Button from './Button'
import Card from './Card'
import './cards.scss'


class Engine extends Component {
state={
    engine:{
        id:1,
        title: "zdjęcie1",
        describe:"To jest silnik nr1",
        price:2500
    },
    engine1:{
        id:2,
        title: "zdjęcie 2",
        describe: "To jest silnik nr2",
        price: 3000
    },
    engine2:{
        id:3,
        title: "zdjęcie 3",
        describe: "To jest silnik nr3",
        price: 3500
    },
    purchasable: true
   
}

purchasableHandler = () => {
    this.setState({purchasable: false})
}  

backHandler = () => {
    this.props.history.goBack();
}



    render(){
        console.log(!this.state.purchasable);
        return (
            <div className="mainpage">
                
                <Navbar/>
                <Question name="Wybierz silnik"/>
              <div className="cards">
          <Card title={this.state.engine.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.engine.describe} price={this.state.engine.price} 
           />
          
          <Card title={this.state.engine1.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.engine1.describe} price={this.state.engine1.price} 
           />
          <Card title= {this.state.engine2.title} disabled={!this.state.purchasable} selected={this.purchasableHandler } describe={this.state.engine2.describe} price={this.state.engine2.price} 
          />
         
          </div>
          <div className="button1">
          
          <Button clicked={this.backHandler} btn="Wstecz" />
     
          <Link style={{textDecoration: 'none'}} to="/carpaint/">
          <Button btn="Kontynuuj" />
          </Link>
          </div>
       
           
          
            </div>
        )
    }
}


export default Engine;
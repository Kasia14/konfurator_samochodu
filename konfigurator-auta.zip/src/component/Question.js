import React from 'react';

import './question.scss'

const  question = (props) => {
    return <h1 className="question "> {props.name}</h1>;
  }

export default question;
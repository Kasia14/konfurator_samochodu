import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import Navbar from './Navbar'
import './page2.scss'
import Question from './Question'
import Button from './Button'
import Card from './Card'
import './cards.scss';


class Equipment extends Component {
    state = {
        additionalEquipment: {
            id: 1,
            title: "zdjęcie1",
            describe: "Dynamiczne reflektory LED",
            price: 1500
        },
        additionalEquipment1: {
            id: 2,
            title: "zdjęcie 2",
            describe: "System dźwiękowy premium",
            price: 1000
        },
        additionalEquipment2: {
            id: 3,
            title: "zdjęcie 3",
            describe: "Zawieszenie sportowe",
            price: 2500
        },
      
    }

    backHandler = () => {
        this.props.history.goBack();
    }
    render() {
        return (
            <div className="mainpage">

                <Navbar />
                <Question name="Dodatkowe wyposażenie: " />
                <div className="cards">
                    <Card title={this.state.additionalEquipment.title} describe={this.state.additionalEquipment.describe} price={this.state.additionalEquipment.price} />
                    <Card title={this.state.additionalEquipment1.title} describe={this.state.additionalEquipment1.describe} price={this.state.additionalEquipment1.price}  />
                    <Card title={this.state.additionalEquipment2.title} describe={this.state.additionalEquipment2.describe} price={this.state.additionalEquipment2.price} />

                </div>
                <div className="button1">

                    <Button clicked={this.backHandler} btn="Wstecz" />

                    <Link style={{ textDecoration: 'none' }} to="/orderSummary">
                        <Button btn="Kontynuuj" />
                    </Link>
                </div>



            </div>
        )
    }
}


export default Equipment;
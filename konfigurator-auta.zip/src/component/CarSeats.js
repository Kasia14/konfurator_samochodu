import React, { Component } from 'react';
import { Link} from 'react-router-dom';

import Navbar from './Navbar'
import './page2.scss'
import Question from './Question'
import Button from './Button'
import Card from './Card'
import './cards.scss';


class CarSeats extends Component {
state={
    carSeats:{
        id:1,
        title: "zdjęcie1",
        describe:"Typ nr1",
        price:5500
    },
    carSeats1:{
        id:2,
        title: "zdjęcie 2",
        describe: "Typ nr2",
        price: 6000
    },
    carSeats2:{
        id:3,
        title: "zdjęcie 3",
        describe: "Typ nr3",
        price: 7500
    },
    purchasable: true
}
purchasableHandler = () => {
    this.setState({purchasable: false})
}  
backHandler = () => {
    this.props.history.goBack();
}
    render(){
        return (
            <div className="mainpage">
                
                <Navbar/>
                <Question name="Typ foteli: "/>
              <div className="cards">
          <Card title={this.state.carSeats.title} disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.carSeats.describe} price={this.state.carSeats.price} />
          <Card title={this.state.carSeats1.title} disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.carSeats1.describe} price={this.state.carSeats1.price} />
          <Card title= {this.state.carSeats2.title} disabled={!this.state.purchasable} selected={this.purchasableHandler }describe={this.state.carSeats2.describe} price={this.state.carSeats2.price} />
         
          </div>
          <div className="button1">
        
          <Button clicked={this.backHandler}btn="Wstecz" />
      
          <Link style={{textDecoration: 'none'}} to="/upholsterycolor/">
          <Button btn="Kontynuuj" />
          </Link>
          </div>
       
           
          
            </div>
        )
    }
}

export default CarSeats;
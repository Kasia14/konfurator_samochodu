const auxility = (props) => props.children;

export default auxility;